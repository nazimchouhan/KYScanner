package com.example.kyscanner.model;

public class StatusModel {
    String KyID;
    String verification;

    public StatusModel(String kyID, String verification) {
        KyID = kyID;
        this.verification = verification;
    }

    public String getKyID() {
        return KyID;
    }

    public void setKyID(String kyID) {
        KyID = kyID;
    }

    public String getVerification() {
        return verification;
    }

    public void setVerification(String verification) {
        this.verification = verification;
    }
}
