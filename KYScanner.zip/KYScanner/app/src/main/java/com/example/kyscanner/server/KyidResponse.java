package com.example.kyscanner.server;

import com.example.kyscanner.model.StatusModel;

import java.util.List;

public class KyidResponse {
    List<StatusModel> VerifiedKyIds;

    public List<StatusModel> getVerifiedKyIds() {
        return VerifiedKyIds;
    }
    public void setVerifiedKyIds(List<StatusModel> VerifiedKyIds) {
        this.VerifiedKyIds = VerifiedKyIds;
    }
}
