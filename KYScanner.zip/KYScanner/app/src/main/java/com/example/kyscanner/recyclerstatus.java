package com.example.kyscanner;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kyscanner.model.StatusModel;

import java.util.ArrayList;


public class recyclerstatus extends RecyclerView.Adapter<recyclerstatus.Viewholder> {
    Context context;
    ArrayList<StatusModel> StatusList;

    public recyclerstatus(Context context,ArrayList<StatusModel> StatusList) {
        this.context=context;
        this.StatusList=StatusList;

    }

    @Override
    public recyclerstatus.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =LayoutInflater.from(context).inflate(R.layout.activity_status,parent,false);

        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull recyclerstatus.Viewholder holder, int position) {
        StatusModel userStatus=StatusList.get(position);
        holder.KyId.setText(userStatus.getKyID());
        holder.KyIdStatus.setText(userStatus.getVerification());
    }

    @Override
    public int getItemCount() {
        return StatusList.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView KyId,KyIdStatus;

        public Viewholder(@NonNull View view) {
            super(view);
            KyId=view.findViewById(R.id.KyId);
            KyIdStatus=view.findViewById(R.id.IDStatus);
        }
    }
}
