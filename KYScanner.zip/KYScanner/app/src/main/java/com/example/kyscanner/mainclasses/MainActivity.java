package com.example.kyscanner.mainclasses;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.kyscanner.R;

public class MainActivity extends AppCompatActivity {
     Button loginButton;
     Toolbar LoginToolbar;
     ProgressBar progressBar;
     EditText LoginEmail,LoginPass;
    private static final String FIXED_EMAIL = "admin@gmail.com";
    private static final String FIXED_PASSWORD = "password123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

        if (isLoggedIn) {
            // Redirect directly to CodeScannerActivity
            Intent intent = new Intent(this, CodeScanner.class);
            startActivity(intent);
            finish();  // Close MainActivity to prevent going back
        }
        setContentView(R.layout.activity_main);
        loginButton=findViewById(R.id.LoginButton);
        LoginEmail=findViewById(R.id.LoginEmail);
        LoginPass=findViewById(R.id.LoginPassword);
        LoginToolbar=findViewById(R.id.LoginToolbar);
        setSupportActionBar(LoginToolbar);
        getSupportActionBar().setTitle("Sign In Page");
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loginUser();
            }
        });
    }
    private void loginUser() {
        String email = LoginEmail.getText().toString().trim();
        String password = LoginPass.getText().toString().trim();

        // Validate user input
        if (TextUtils.isEmpty(email)) {
            LoginEmail.setError("Email is required!");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            LoginPass.setError("Password is required!");
            return;
        }


        progressBar.setVisibility(View.VISIBLE);


        if (email.equals(FIXED_EMAIL) && password.equals(FIXED_PASSWORD)) {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
            SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isLoggedIn", true);
            editor.apply();
            Intent intent = new Intent(MainActivity.this, CodeScanner.class);
            startActivity(intent);
            finish();
        } else {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(MainActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();
        }
    }
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

}