package com.example.kyscanner.server;

import com.example.kyscanner.server.KyidRequest;
import com.example.kyscanner.server.KyidResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public class ApiService {
    @POST("verifyKyids")
        // Replace with your API endpoint
    Call<KyidResponse> verifyKyids(@Body KyidRequest request) {
        return null;
    }
}
