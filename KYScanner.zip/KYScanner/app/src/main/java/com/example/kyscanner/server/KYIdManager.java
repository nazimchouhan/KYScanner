package com.example.kyscanner.server;

import android.util.Log;

import com.example.kyscanner.model.StatusModel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class KYIdManager {
    public static final int BatchSize=30;
    private static KYIdManager instance;
    public List<String> kyidlist=new ArrayList<>();
    public Set<String> ScannedKyIds=new HashSet<>();
    public ArrayList<StatusModel> verifiedKYidsList=new ArrayList<>();
    public int totalScan=0;


    public static KYIdManager getInstance() {
        if (instance == null) {
            instance = new KYIdManager();
        }
        return instance;
    }
    public void addScannedKyIDs(String KyID){
        if(!ScannedKyIds.contains(KyID)){
            ScannedKyIds.add(KyID);
            kyidlist.add(KyID);
            totalScan++;
            if(totalScan==BatchSize){
                sendBatchToServer();
            }
        }
        else {
            Log.d("KyidManager", "Duplicate Kyid ignored: " + KyID);
        }
    }
    private void sendBatchToServer(){
        if(kyidlist.size()==0) {
            return;
        }
        ApiService apiService = RetrofitClient.getApiService();
        Call<KyidResponse> call = apiService.verifyKyids(new KyidRequest(kyidlist));
        call.enqueue(new Callback<KyidResponse>() {
            @Override
            public void onResponse(Call<KyidResponse> call, Response<KyidResponse> response) {
                if(response.isSuccessful() && response.body()!=null){
                    List<StatusModel> verifiedKyIds = response.body().getVerifiedKyIds();
                    updateKyidStatus(verifiedKyIds);
                }else{
                    Log.e("KyidManager", "Server error: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<KyidResponse> call, Throwable t) {
                Log.e("KyidManager", "Network error: " + t.getMessage());
            }
        });
    }
    public void updateKyidStatus(List<StatusModel> verifiedList){
        verifiedKYidsList.addAll(verifiedList);
        kyidlist.clear();
        for (StatusModel status : verifiedList) {
            Log.d("KyidManager", "Kyid: " + status.getKyID() + " | Verified: " + status.getVerification());
        }
    }
    public ArrayList<StatusModel> getVerifiedKyids() {
        return verifiedKYidsList;
    }
}
