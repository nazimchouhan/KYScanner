package com.example.kyscanner.mainclasses;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.kyscanner.R;

public class Success extends AppCompatActivity {
    Toolbar userDetailToolbar;
    CardView cardview;
    ImageView UserImage;
    ProgressBar SuccessProgressBar;
    TextView UserName;
    Button BackButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
        userDetailToolbar=findViewById(R.id.UserDetailToolbar);
        UserImage=findViewById(R.id.profilePic);
        cardview=findViewById(R.id.cardView);
        BackButton=findViewById(R.id.BackButton);
        UserName=findViewById(R.id.userName);
        SuccessProgressBar=findViewById(R.id.SuccessProgressbar);
        setSupportActionBar(userDetailToolbar);
        getSupportActionBar().setTitle("User Detail");
        Intent intent=getIntent();
        String Username=intent.getStringExtra("userName");
        String profilePic = getIntent().getStringExtra("profilePic");
        long ScanTime = getIntent().getLongExtra("ScanTime", 0);
        Toast.makeText(this, "The Scan Time is:" + ScanTime + "ms", Toast.LENGTH_SHORT).show();

        if (Username != null && profilePic != null) {
            // Load user details and hide progress bar
            UserName.setText(Username);
            int imageResId = getResources().getIdentifier(profilePic, "drawable", getPackageName());
            Glide.with(this)
                    .load(imageResId)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            SuccessProgressBar.setVisibility(View.GONE); // Hide progress bar on failure
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            SuccessProgressBar.setVisibility(View.GONE); // Hide progress bar when image loads
                            cardview.setVisibility(View.VISIBLE);
                            userDetailToolbar.setVisibility(View.VISIBLE);
                            BackButton.setVisibility(View.VISIBLE);// Show user details
                            return false;
                        }
                    })
                    .into(UserImage);
        } else {
            SuccessProgressBar.setVisibility(View.GONE); // Hide progress if no data found
        }
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Success.this, CodeScanner.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(Success.this, CodeScanner.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
