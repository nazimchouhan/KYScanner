package com.example.kyscanner.mainclasses;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.kyscanner.R;

public class InvalidUser extends AppCompatActivity {
   View invalidUserView;
   Button invalidUserBackButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invalid_user);

        invalidUserBackButton=findViewById(R.id.InvalidUserBackButton);

        invalidUserBackButton.setOnClickListener(v -> {
            Intent intent = new Intent(InvalidUser.this, CodeScanner.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

    }
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(InvalidUser.this, CodeScanner.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

    }
}