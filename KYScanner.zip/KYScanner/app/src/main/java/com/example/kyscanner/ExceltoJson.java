package com.example.kyscanner;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;
import androidx.work.WorkerParameters;

import android.content.Context;
import android.content.SharedPreferences;
import android.health.connect.datatypes.units.Length;

import androidx.work.Worker;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;


public class ExceltoJson extends Worker {
    private  static final String JsonFileName = "users.json";
    private static final String ExcelUrl="";
    private static String ExcelSync="ExcelSyncPrefs";
    private static String LastRowKey="lastProcessedKey";

    public ExceltoJson(Context context, WorkerParameters params) {
        super(context, params);
    }
    public Result doWork(){
        File excelfile=downloadExcelfile();
        if(excelfile!=null){
            JSONArray newEntries=getNewRowsData(excelfile);
            if(newEntries.length()>0){
                appendJson(getApplicationContext(),newEntries);
            }
        }
        return Result.success();
    }
    private File downloadExcelfile(){
        try{
            URL url=new URL(ExcelUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.connect();
            if(connection.getResponseCode()==HttpURLConnection.HTTP_OK){
                File file=new File(getApplicationContext().getCacheDir(),"ExcelFile");
                try(InputStream inputStream=connection.getInputStream();
                    FileOutputStream outputStream=new FileOutputStream(file)){
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }
                    return file;

                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }
    private JSONArray getNewRowsData(File file){
        try(FileInputStream fis=new FileInputStream(file);
             Workbook workbook=new XSSFWorkbook(fis)) {
            Sheet sheet=workbook.getSheetAt(0);
            int lastRowIndex= sheet.getLastRowNum();
            int lastProcessedRow=getLastProcessedRow(getApplicationContext());
            if (lastProcessedRow >= lastRowIndex) {
                return new JSONArray(); // No new entries
            }
            JSONArray newEntries=new JSONArray();
            Row headerrow= sheet.getRow(0);
            for(int rowIndex=lastProcessedRow+1;rowIndex<=lastRowIndex;rowIndex++){
                Row row= sheet.getRow(rowIndex);
                if(row!=null){
                    JSONObject jsonObject=new JSONObject();
                    for(int i=0;i<row.getLastCellNum();i++){
                        Cell cell=row.getCell(i);
                        String Key=headerrow.getCell(i).getStringCellValue();
                        String value=(cell!=null)?cell.toString():"";
                        jsonObject.put(Key,value);
                    }
                    newEntries.put(jsonObject);
                }

            }
            saveLastProcessedRow(getApplicationContext(), lastRowIndex);
            return newEntries;

        }
         catch (Exception e) {
           e.printStackTrace();
        }
        return new JSONArray();
    }
    private void appendJson(Context context,JSONArray newEntries){
        try {
            JSONArray jsonArray = readJsonFromFile(context);
            for (int i = 0; i < newEntries.length(); i++) {
                jsonArray.put(newEntries.getJSONObject(i));
            }
            saveJsonToFile(context, jsonArray);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    private JSONArray readJsonFromFile(Context context){
        File file = new File(context.getFilesDir(), "users.json");

        if (!file.exists()) {
                return new JSONArray(); // Return an empty array if file doesn't exist
        }

        try (FileInputStream fis = new FileInputStream("users.json");
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)) {

            StringBuilder jsonText = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonText.append(line); // Read file line by line
            }

            return new JSONArray(jsonText.toString()); // Convert collected text to JSONArray

        } catch (Exception e) {
            e.printStackTrace();
            return new JSONArray(); // Return an empty array if reading fails
        }
    }
    private void saveJsonToFile(Context context,JSONArray jsonArray){
        try{
            JSONArray jsonArray1=readJsonFromFile(context);
            for(int i = 0; i<jsonArray.length();i++){
                jsonArray1.put(jsonArray.getJSONObject(i));
            }
            try (FileOutputStream fos = context.openFileOutput("users.json", Context.MODE_PRIVATE)) {
                fos.write(jsonArray.toString().getBytes());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }
    public int getLastProcessedRow(Context context){
        SharedPreferences prefs = context.getSharedPreferences(ExcelSync, Context.MODE_PRIVATE);
        return prefs.getInt(LastRowKey, -1); // Default to -1 if no previous value exists

    }
    public void saveLastProcessedRow(Context context,int rowIndex){
        SharedPreferences prefs = context.getSharedPreferences(ExcelSync, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(LastRowKey, rowIndex);
        editor.apply();

    }
    public static void scheduleExcelSync(Context context) {
        WorkRequest workRequest = new PeriodicWorkRequest.Builder(ExceltoJson.class, 15, TimeUnit.MINUTES)
                .setConstraints(new Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build();

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "ExcelSyncWork",
                ExistingPeriodicWorkPolicy.KEEP,
                (PeriodicWorkRequest) workRequest
        );
    }
}
