package com.example.kyscanner.mainclasses;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.animation.ObjectAnimator;
import android.hardware.camera2.CameraManager;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraControl;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.example.kyscanner.JSonReader;
import com.example.kyscanner.R;
import com.example.kyscanner.model.UserModel;
import com.example.kyscanner.server.KYIdManager;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.ArrayList;
import java.util.concurrent.Executors;

public class CodeScanner extends AppCompatActivity {
    private static final int CAMERA_REQUEST_CODE = 100;

    private PreviewView cameraPreview;
    private Toolbar scannerToolbar;
    private CameraManager cameraManager;
    private View scanLine;
    KYIdManager Kyidmanager;

    ImageView flashLight;
    private boolean isOverlayShown = false;
    private boolean isQRCodeDetected = false;
    private boolean isScanning = false;
    private boolean isFlashOn=false;
    private ProcessCameraProvider cameraProvider;
    private BarcodeScanner barcodeScanner;
    String cameraId;
    private Camera camera;
    CameraControl cameraControl;
    private ImageAnalysis imageAnalysis;
    private SharedPreferences sharedPreferences;

    private long startTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_scanner);

        scannerToolbar = findViewById(R.id.ScannerToolbar);
        cameraPreview = findViewById(R.id.PreviewCameraScanner);
        flashLight=findViewById(R.id.FlashLight);
        scanLine = findViewById(R.id.scanningLine);
        barcodeScanner = BarcodeScanning.getClient(); // Only one instance

        setSupportActionBar(scannerToolbar);
        getSupportActionBar().setTitle("Scan QR Code");
        sharedPreferences = getSharedPreferences("FlashlightPrefs", MODE_PRIVATE);
        isFlashOn = sharedPreferences.getBoolean("isFlashOn", false);
        Kyidmanager=new KYIdManager();
        startCamera();
        startScanLineAnimation();

        flashLight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFlashlight();
            }
        });
    }
    private void startScanLineAnimation() {
        ObjectAnimator animator = ObjectAnimator.ofFloat(scanLine, "translationY", 0f, 800f);
        animator.setDuration(1500);
        animator.setRepeatCount(ObjectAnimator.INFINITE);
        animator.setRepeatMode(ObjectAnimator.REVERSE);
        animator.start();
    }
    private void toggleFlashlight() {
        if (cameraControl == null) {
            return; // Avoid NullPointerException
        }

        isFlashOn = !isFlashOn;
        cameraControl.enableTorch(isFlashOn);

        // Save flashlight state in SharedPreferences
        sharedPreferences.edit().putBoolean("isFlashOn", isFlashOn).apply();
    }
    @Override
    protected void onResume() {
        super.onResume();
        isFlashOn = sharedPreferences.getBoolean("isFlashOn", false); // ✅ Restore state on resume
        if (isFlashOn && cameraControl != null) {
            cameraControl.enableTorch(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuitem, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isLoggedIn", false);
            editor.apply();
            Intent intent = new Intent(CodeScanner.this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        else{
            Intent intent=new Intent(getApplicationContext(), Status.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void startCamera() {
        if (cameraProvider != null) {
            cameraProvider.unbindAll(); // Unbind previous instances before re-binding
        }

        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                cameraProvider = cameraProviderFuture.get();
                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(cameraPreview.getSurfaceProvider());

                imageAnalysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

                imageAnalysis.setAnalyzer(Executors.newFixedThreadPool(2), image -> {
                    @SuppressLint("UnsafeOptInUsageError")
                    Image mediaImage = image.getImage();
                    if (mediaImage != null && !isQRCodeDetected) {
                        InputImage inputImage = InputImage.fromMediaImage(mediaImage, image.getImageInfo().getRotationDegrees());
                        startTime = System.currentTimeMillis();
                        scanQRCode(inputImage, image);
                    } else {
                        image.close(); // Ensure imageProxy is closed to prevent memory leaks
                    }
                });

                camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
                cameraControl= camera.getCameraControl();
                if (getIntent().getBooleanExtra("isFirstLaunch", true)) {
                    // Always start with flashlight OFF
                    isFlashOn = false;
                    sharedPreferences.edit().putBoolean("isFlashOn", false).apply();
                    getIntent().putExtra("isFirstLaunch", false); // Mark app as not first launch
                } else {
                    // Restore flashlight state when coming back from another activity
                    isFlashOn = sharedPreferences.getBoolean("isFlashOn", false);
                }

                cameraControl.enableTorch(isFlashOn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void scanQRCode(InputImage image, ImageProxy imageProxy) {
        if (isScanning) {
            imageProxy.close();
            return;
        }

        isScanning = true;

        barcodeScanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    if (barcodes.isEmpty()) {
                        isScanning=false;
                        imageProxy.close();
                        return;
                    }

                    Barcode barcode = barcodes.get(0);
                    String qrResult = barcode.getRawValue();
                    if(qrResult!=null){
                        Kyidmanager.addScannedKyIDs(qrResult);
                    }

                    long scanTime = System.currentTimeMillis() - startTime;

                    runOnUiThread(() -> {
                        JSonReader jsonReader = new JSonReader(this);
                        ArrayList<UserModel> userlist = jsonReader.getUserDetails(qrResult);

                        if (!userlist.isEmpty()) {
                            UserModel user = userlist.get(0);
                            String userName = user.getName();
                            String profilePic = user.getProfilePic();

                            if (userName != null && profilePic != null) {
                                Log.d("QR Scanner", "ProfilePic & username: found successfully");
                            }

                            Intent intent = new Intent(CodeScanner.this, Success.class);
                            intent.putExtra("userName", userName);
                            intent.putExtra("profilePic", profilePic);
                            intent.putExtra("ScanTime", scanTime);
                            startActivity(intent);
                            isQRCodeDetected = true;
                            isScanning = false;
                        } else {
                            showInvalidQRCodeOverlay();
                        }
                    });

                    imageProxy.close();
                })
                .addOnFailureListener(e -> {
                    Log.e("QR Scanner", "Error: ", e);
                    isScanning = false;
                    imageProxy.close();
                });
    }

    private void showInvalidQRCodeOverlay() {
        if (!isOverlayShown) {
            isOverlayShown = true;
            Intent intent = new Intent(CodeScanner.this, InvalidUser.class);
            startActivity(intent);
            finish();
        }

        new Handler().postDelayed(() -> isScanning = false, 1000);
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        finishAffinity();
    }
}