package com.example.kyscanner.server;

import java.util.List;

public class KyidRequest {
    List<String> KyIds;
    public KyidRequest(List<String> KyIds){
        this.KyIds=KyIds;
    }
    public List<String> getKyIds(){
        return KyIds;
    }

}
