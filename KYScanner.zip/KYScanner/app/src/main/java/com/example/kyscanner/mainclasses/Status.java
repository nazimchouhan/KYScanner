package com.example.kyscanner.mainclasses;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.kyscanner.R;
import com.example.kyscanner.model.StatusModel;
import com.example.kyscanner.recyclerstatus;
import com.example.kyscanner.server.KYIdManager;

import java.util.ArrayList;

public class Status extends AppCompatActivity{
    RecyclerView RecyclerStatus;
    recyclerstatus StatusAdapter;
    ArrayList<StatusModel> StatusList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        StatusList = KYIdManager.getInstance().getVerifiedKyids();
        if (StatusList == null) {
            StatusList = new ArrayList<>();
        }
        RecyclerStatus=findViewById(R.id.recyclerViewStatus);
        RecyclerStatus.setLayoutManager(new LinearLayoutManager(this));
        StatusAdapter = new recyclerstatus(this, StatusList);
        RecyclerStatus.setAdapter(StatusAdapter);
    }
}