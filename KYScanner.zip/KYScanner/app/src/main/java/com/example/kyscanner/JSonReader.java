package com.example.kyscanner;

import static android.widget.Toast.LENGTH_SHORT;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.widget.Toast;

import com.example.kyscanner.model.UserModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class JSonReader {
    private Context context;


    public JSonReader(Context context) {
        this.context = context;

    }
    private String loadJSONFromAsset(String filename) {
        String json = null;
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open(filename);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException e) {
            Log.e("JSonReader", "Error loading JSON file: ", e);
        }
        return json;
    }


    public ArrayList<UserModel> getUserDetails(String emailKey) {
        String jsonData = loadJSONFromAsset("users.json"); //load Json from Assets

        ArrayList<UserModel> mainlist = new ArrayList<>();
        if (jsonData != null) {
            Gson gson = new Gson();
            Type mapType = new TypeToken<Map<String, List<UserModel>>>() {}.getType();
            Map<String, List<UserModel>> userMap = gson.fromJson(jsonData, mapType);

            if (userMap.containsKey(emailKey)) {
                Log.d("emailKey","Successfully matched");
                List<UserModel> list = userMap.get(emailKey);
                if (!list.isEmpty()) {
                    UserModel user = list.get(0);
                    mainlist.add(user);
                } else {
                    System.out.println("User list is empty for the provided email!");
                }

            } else {
                Toast.makeText(context, "User is not Found", LENGTH_SHORT).show();


            }
        }else {
            System.out.println("Failed to load JSON file!");
        }
        return mainlist;
    }
}

